#include "stdafx.h"
#include "Flange.h"

Flange::Flange(int numChannels, int sampleRate) : BaseEffect(numChannels, sampleRate)
{
    m_delaySamples = static_cast<int>(sampleRate * 0.005); // 5 ms
    m_depth = 0.5f; 
    m_rate = 0.5f; 
    m_feedback = 0.5f; 
    m_phase = 0.0f;
    m_delayIndex = 0;

    m_delayBuffer.resize(numChannels, std::vector<double>(m_delaySamples, 0.0));
}

Flange::~Flange()
{ }

void Flange::ProcessInput(double* inputFrame, double* outputFrame)
{
    for (int c = 0; c < m_numChannels; c++)
    {
        double mod = (sin(m_phase * 2.0 * 3.1415926535) + 1.0) * 0.5;
        int delay = static_cast<int>(mod * m_delaySamples); 

        double delayedSample = m_delayBuffer[c][(m_delayIndex + m_delaySamples - delay) % m_delaySamples];

        outputFrame[c] = inputFrame[c] + (delayedSample * m_depth);

        m_delayBuffer[c][m_delayIndex] = inputFrame[c] + (delayedSample * m_feedback);

        m_delayIndex = (m_delayIndex + 1) % m_delaySamples;
    }

    m_phase += m_rate / m_sampleRate;

    if (m_phase >= 1.0)
    {
        m_phase -= 1.0;
    }
}
