#include "stdafx.h"
#include "BaseEffect.h"

BaseEffect::BaseEffect(int numChannels, int sampleRate)
{
	m_numChannels = numChannels;
	m_sampleRate = sampleRate;
}

BaseEffect::~BaseEffect()
{

}
