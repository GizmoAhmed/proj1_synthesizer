#include "stdafx.h"
#include "Ring.h"

Ring::Ring(int numChannels, int sampleRate) : BaseEffect(numChannels, sampleRate)
{
	m_phase = 0;
    m_modFreq = 10; //hz
}

Ring::~Ring()
{
}

void Ring::ProcessInput(double* inputFrame, double* outputFrame)
{
    double const mod = sin(2.0 * 3.14159265f * m_modFreq * m_phase / m_sampleRate);

    for (int c = 0; c < m_numChannels; c++)
    {
        outputFrame[c] = mod * inputFrame[c];
    }

    m_phase ++;

    if (m_phase >= m_sampleRate)
    {
        m_phase = 0;
    }
}
