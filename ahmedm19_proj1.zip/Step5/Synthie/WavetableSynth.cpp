#include "stdafx.h"
#include "WavetableSynth.h"

WaveTableSynth::WaveTableSynth(int tableSize, double frequency, double sampleRate)
    : m_size(tableSize), m_freq(frequency), m_sampleRate(sampleRate), m_phase(0)
{
    m_waveTable.resize(tableSize);

    for (int i = 0; i < m_size; ++i) {
        m_waveTable[i] = 2.0 * (i / (double)m_size) - 1.0;
    }


    m_phaseJump = (frequency * tableSize) / sampleRate;
}

bool WaveTableSynth::Generate(double& output) 
{
    int i = static_cast<int>(m_phase);
    double diff = m_phase - i;
    int nextIndex = (i + 1) % m_size;

    output = (1 - diff) * m_waveTable[i] + diff * m_waveTable[nextIndex] * 0.2;

    m_phase += m_phaseJump;

    if (m_phase >= m_size) 
    {
        m_phase -= m_size;
    }

    return true;
}