#pragma once
#include "BaseEffect.h"
#include <vector>

class Flange : public BaseEffect
{
	public:
		Flange(int numChannels, int sampleRate);
		~Flange();

		void ProcessInput(double* inputFrame, double* outputFrame) override;

	private:
		int m_delaySamples;
		float m_depth;
		float m_rate;
		float m_feedback;
		float m_phase;
		std::vector<std::vector<double>> m_delayBuffer;
		int m_delayIndex;
};

