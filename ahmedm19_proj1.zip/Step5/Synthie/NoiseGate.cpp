#include "stdafx.h"
#include "NoiseGate.h"

NoiseGate::NoiseGate(int numChannels, int sampleRate) : BaseEffect(numChannels, sampleRate)
{
	m_threshold = -40.0f;
	m_attack = 0.01f;
	m_release = 0.1f;
	m_gain = 1.0f;
}

NoiseGate::~NoiseGate() {}

void NoiseGate::ProcessInput(double* inputFrame, double* outputFrame)
{
    double scale = pow(10.0, m_threshold / 20.0);

    for (int c = 0; c < m_numChannels; c++)
    {
        double iSample = inputFrame[c]; // copy

        if (fabs(iSample) > scale) 
        {
            m_gain = 1.0; 
        }
        else
        {
            m_gain *= (1.0 - m_release * m_sampleRate);
            if (m_gain < 0)
            {
                m_gain = 0;
            }
        }

        outputFrame[c] = iSample * m_gain;
    }
}
