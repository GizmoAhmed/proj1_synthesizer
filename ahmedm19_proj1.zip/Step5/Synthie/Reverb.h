#pragma once
#include <gdipluseffects.h>
#include "BaseEffect.h"
#include <vector>

class Reverb : public BaseEffect
{
	public:
		Reverb(int numChannels, int sampleRate);
		~Reverb();

		void ProcessInput(double* inputFrame, double* outputFrame) override;	

	private:
		int m_delayIndex; 
		std::vector<std::vector<double>> m_delayBuffer; 

		double m_feedback;
		double m_delayCoef;
		
};

