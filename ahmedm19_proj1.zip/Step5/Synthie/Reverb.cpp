#include "stdafx.h"
#include "Reverb.h"

Reverb::Reverb(int numChannels, int sampleRate) : BaseEffect(numChannels, sampleRate)
{
    m_delayCoef = 0.55;
    m_feedback = 1.1f;
    m_delayIndex = 0;

    int delaySamples = static_cast<int>(m_sampleRate * m_delayCoef);

    m_delayBuffer.resize(m_numChannels);

    for (int c = 0; c < m_numChannels; c++)
    {
        m_delayBuffer[c].resize(delaySamples, 0.0);
    }
}

Reverb::~Reverb() { }

void Reverb::ProcessInput(double* inputFrame, double* outputFrame)
{
    const int delaySamples = static_cast<int>(m_sampleRate * m_delayCoef);

    for (int c = 0; c < m_numChannels; c++)
    {
        double inputSample = inputFrame[c];

        double delayedSample = m_delayBuffer[c][m_delayIndex];

        outputFrame[c] = inputSample + delayedSample * m_feedback;

        // outputFrame[c] = (inputSample * 0.8) + (delayedSample * feedback);

        m_delayBuffer[c][m_delayIndex] = inputSample + delayedSample * m_feedback;

        m_delayIndex = (m_delayIndex + 1) % delaySamples;
    }
}




