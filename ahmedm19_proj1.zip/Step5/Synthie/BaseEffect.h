#pragma once
class BaseEffect
{
	public:
		BaseEffect(int numChannels, int sampleRate);

		~BaseEffect();

		int m_numChannels;

		void SetNumChannels(int numChannels) { m_numChannels = numChannels; }

		float m_sampleRate;

		void SetSampleRate(float sampleRate) { m_sampleRate = sampleRate; }

		void virtual ProcessInput(double* inputFrame, double* outputFrame) = 0;

	private:
};

