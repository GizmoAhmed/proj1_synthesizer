#pragma once
#include <vector>

class WaveTableSynth {
    public:
        WaveTableSynth(int tableSize, double frequency, double sampleRate);

        bool Generate(double& outSample);

    private:
        std::vector<double> m_waveTable;
        int m_size;

        double m_phase;
        double m_phaseJump;

        double m_freq;
        double m_sampleRate;
        
};


