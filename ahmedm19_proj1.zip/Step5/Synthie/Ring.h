#pragma once
#include "BaseEffect.h"

class Ring : public BaseEffect
{
	public:
		Ring(int numChannels, int sampleRate);
		~Ring();

		void ProcessInput(double* inputFrame, double* outputFrame) override;

	private:
		double m_modFreq;
		double m_phase;        
};

