#pragma once
#include "BaseEffect.h"
class NoiseGate : public BaseEffect
{
	public:
		NoiseGate(int numChannels, int sampleRate);
		~NoiseGate();

		void ProcessInput(double* inputFrame, double* outputFrame) override;

	private:
		double m_threshold;  
		double m_attack; 
		double m_release; 
		double m_gain; 
};

